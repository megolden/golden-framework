# GoldenFramework
A .net framework library that contains some useful components.

Please refer to 'Golden.Tests' folder and open corespond test file, these test files contains how using components.

Thanks;
